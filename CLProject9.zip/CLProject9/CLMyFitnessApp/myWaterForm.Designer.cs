﻿namespace CLMyFitnessApp
{
    partial class myWaterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(myWaterForm));
            this.addLabel = new System.Windows.Forms.Label();
            this.dateLabel = new System.Windows.Forms.Label();
            this.addWaterButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.waterPicture1 = new System.Windows.Forms.PictureBox();
            this.waterPicture2 = new System.Windows.Forms.PictureBox();
            this.waterPicture4 = new System.Windows.Forms.PictureBox();
            this.waterPicture3 = new System.Windows.Forms.PictureBox();
            this.waterPicture8 = new System.Windows.Forms.PictureBox();
            this.waterPicture7 = new System.Windows.Forms.PictureBox();
            this.waterPicture6 = new System.Windows.Forms.PictureBox();
            this.waterPicture5 = new System.Windows.Forms.PictureBox();
            this.waterLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture5)).BeginInit();
            this.SuspendLayout();
            // 
            // addLabel
            // 
            this.addLabel.AutoSize = true;
            this.addLabel.Location = new System.Drawing.Point(24, 30);
            this.addLabel.Name = "addLabel";
            this.addLabel.Size = new System.Drawing.Size(123, 13);
            this.addLabel.TabIndex = 0;
            this.addLabel.Text = "Add to your water count:";
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateLabel.Location = new System.Drawing.Point(352, 30);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(67, 15);
            this.dateLabel.TabIndex = 1;
            this.dateLabel.Text = "11/10/2018";
            // 
            // addWaterButton
            // 
            this.addWaterButton.Location = new System.Drawing.Point(72, 55);
            this.addWaterButton.Name = "addWaterButton";
            this.addWaterButton.Size = new System.Drawing.Size(75, 23);
            this.addWaterButton.TabIndex = 3;
            this.addWaterButton.Text = "&Water ++";
            this.addWaterButton.UseVisualStyleBackColor = true;
            this.addWaterButton.Click += new System.EventHandler(this.addWaterButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(352, 55);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(67, 23);
            this.closeButton.TabIndex = 4;
            this.closeButton.Text = "&Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // waterPicture1
            // 
            this.waterPicture1.Image = ((System.Drawing.Image)(resources.GetObject("waterPicture1.Image")));
            this.waterPicture1.Location = new System.Drawing.Point(27, 96);
            this.waterPicture1.Name = "waterPicture1";
            this.waterPicture1.Size = new System.Drawing.Size(51, 93);
            this.waterPicture1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.waterPicture1.TabIndex = 5;
            this.waterPicture1.TabStop = false;
            // 
            // waterPicture2
            // 
            this.waterPicture2.Image = ((System.Drawing.Image)(resources.GetObject("waterPicture2.Image")));
            this.waterPicture2.Location = new System.Drawing.Point(78, 96);
            this.waterPicture2.Name = "waterPicture2";
            this.waterPicture2.Size = new System.Drawing.Size(51, 93);
            this.waterPicture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.waterPicture2.TabIndex = 6;
            this.waterPicture2.TabStop = false;
            // 
            // waterPicture4
            // 
            this.waterPicture4.Image = ((System.Drawing.Image)(resources.GetObject("waterPicture4.Image")));
            this.waterPicture4.Location = new System.Drawing.Point(180, 96);
            this.waterPicture4.Name = "waterPicture4";
            this.waterPicture4.Size = new System.Drawing.Size(51, 93);
            this.waterPicture4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.waterPicture4.TabIndex = 8;
            this.waterPicture4.TabStop = false;
            // 
            // waterPicture3
            // 
            this.waterPicture3.Image = ((System.Drawing.Image)(resources.GetObject("waterPicture3.Image")));
            this.waterPicture3.Location = new System.Drawing.Point(129, 96);
            this.waterPicture3.Name = "waterPicture3";
            this.waterPicture3.Size = new System.Drawing.Size(51, 93);
            this.waterPicture3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.waterPicture3.TabIndex = 7;
            this.waterPicture3.TabStop = false;
            // 
            // waterPicture8
            // 
            this.waterPicture8.Image = ((System.Drawing.Image)(resources.GetObject("waterPicture8.Image")));
            this.waterPicture8.Location = new System.Drawing.Point(384, 96);
            this.waterPicture8.Name = "waterPicture8";
            this.waterPicture8.Size = new System.Drawing.Size(51, 93);
            this.waterPicture8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.waterPicture8.TabIndex = 12;
            this.waterPicture8.TabStop = false;
            // 
            // waterPicture7
            // 
            this.waterPicture7.Image = ((System.Drawing.Image)(resources.GetObject("waterPicture7.Image")));
            this.waterPicture7.Location = new System.Drawing.Point(333, 96);
            this.waterPicture7.Name = "waterPicture7";
            this.waterPicture7.Size = new System.Drawing.Size(51, 93);
            this.waterPicture7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.waterPicture7.TabIndex = 11;
            this.waterPicture7.TabStop = false;
            // 
            // waterPicture6
            // 
            this.waterPicture6.Image = ((System.Drawing.Image)(resources.GetObject("waterPicture6.Image")));
            this.waterPicture6.Location = new System.Drawing.Point(282, 96);
            this.waterPicture6.Name = "waterPicture6";
            this.waterPicture6.Size = new System.Drawing.Size(51, 93);
            this.waterPicture6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.waterPicture6.TabIndex = 10;
            this.waterPicture6.TabStop = false;
            // 
            // waterPicture5
            // 
            this.waterPicture5.Image = ((System.Drawing.Image)(resources.GetObject("waterPicture5.Image")));
            this.waterPicture5.Location = new System.Drawing.Point(231, 96);
            this.waterPicture5.Name = "waterPicture5";
            this.waterPicture5.Size = new System.Drawing.Size(51, 93);
            this.waterPicture5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.waterPicture5.TabIndex = 9;
            this.waterPicture5.TabStop = false;
            // 
            // waterLabel
            // 
            this.waterLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.waterLabel.Location = new System.Drawing.Point(27, 55);
            this.waterLabel.Name = "waterLabel";
            this.waterLabel.Size = new System.Drawing.Size(39, 23);
            this.waterLabel.TabIndex = 13;
            this.waterLabel.Text = "0";
            this.waterLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // myWaterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 204);
            this.Controls.Add(this.waterLabel);
            this.Controls.Add(this.waterPicture8);
            this.Controls.Add(this.waterPicture7);
            this.Controls.Add(this.waterPicture6);
            this.Controls.Add(this.waterPicture5);
            this.Controls.Add(this.waterPicture4);
            this.Controls.Add(this.waterPicture3);
            this.Controls.Add(this.waterPicture2);
            this.Controls.Add(this.waterPicture1);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.addWaterButton);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.addLabel);
            this.Name = "myWaterForm";
            this.Text = "My Water";
            this.Load += new System.EventHandler(this.myWaterForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterPicture5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label addLabel;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.Button addWaterButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.PictureBox waterPicture1;
        private System.Windows.Forms.PictureBox waterPicture2;
        private System.Windows.Forms.PictureBox waterPicture4;
        private System.Windows.Forms.PictureBox waterPicture3;
        private System.Windows.Forms.PictureBox waterPicture8;
        private System.Windows.Forms.PictureBox waterPicture7;
        private System.Windows.Forms.PictureBox waterPicture6;
        private System.Windows.Forms.PictureBox waterPicture5;
        private System.Windows.Forms.Label waterLabel;
    }
}